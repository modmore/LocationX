<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sxStore',
    1 => 'sxMarker',
    2 => 'sxCategory',
  ),
);