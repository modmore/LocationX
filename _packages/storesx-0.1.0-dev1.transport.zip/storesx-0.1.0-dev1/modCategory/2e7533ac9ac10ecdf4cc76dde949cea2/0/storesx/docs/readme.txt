@name       StoresX
@author     Mark Hamstra <hello@markhamstra.com>
@license    GPL GNU v2

StoresX manages, lists and maps your locations.

Documentation: 		http://rtfm.modx.com/display/ADDON/StoresX
Bugs & Features: 	https://github.com/Mark-H/StoresX/issues

Several included Marker Images (assets/components/storesx/img/markers)
have been included from http://www.mapchannels.com/Markers.aspx
