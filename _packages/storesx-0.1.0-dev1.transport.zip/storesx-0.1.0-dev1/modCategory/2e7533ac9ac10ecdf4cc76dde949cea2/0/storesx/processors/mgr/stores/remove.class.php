<?php

class sxStoreRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'sxStore';
}
return 'sxStoreRemoveProcessor';
